import UIKit

//Computed property:
var computedProperty: String {
    return "Computed property"
}
computedProperty //  "Computed property"


//Stored property:
struct StoredProperty{
var storedProperty: String
}
let storedPropertyObject = StoredProperty(storedProperty: "Ahmet")
